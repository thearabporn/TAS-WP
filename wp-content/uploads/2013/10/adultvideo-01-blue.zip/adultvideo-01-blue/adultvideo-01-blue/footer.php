        <div class="footer">
            
            <div class="footer-links">
                
                <p>Disclaimer: This site has a zero-tolerance policy against illegal pornography. <a href="http://www.megasessotv.com/" target="_blank">MegaSesso</a> videos and photos are provided by 3rd parties. We take no responsibility for the content <br /> on any website which we link to, please use your own discretion while surfing the links. Powered by <a href="http://wordpress.org/">Wordpress</a> and <a href="http://www.adultwpthemes.org/">Adult Wordpress Themes</a></p>
            
            </div>
    
        </div>
        
        <?php wp_footer(); ?>

    </body>

</html>

