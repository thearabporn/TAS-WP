<form method="post" class="searchform" action="<?php echo site_url(); ?>">

    <div>
        
        <input type="text" onfocus="javascript: if(this.value == 'Search') this.value = '';" onblur="javascript: if(this.value == '') { this.value = 'Search';}" value="Search" name="s" id="s" />
        
        <input type="submit" id="searchsubmit" value="" />
        
        <br class="clear" />
    
    </div>

</form>

