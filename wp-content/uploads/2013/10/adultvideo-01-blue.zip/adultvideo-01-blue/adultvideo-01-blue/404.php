<?php get_header(); ?>
    
    <div class="main">
    
        <div class="content">
        
            <div class="posts">
        
                <h2 class="page-title">Sorry, no posts matched your criteria</h2>
        
            </div>
            
            <?php get_sidebar('left'); ?>
        
        </div>
        
        <?php get_sidebar('right'); ?>
        
        <div class="clear"></div>
        
    </div>
    
<?php get_footer(); ?>

